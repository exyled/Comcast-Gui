API documentation
-----------------

The API can be found `here <http://legrandin.github.com/pycryptodome>`_.
Soon it will be moved on these pages.
